import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-contact-us',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './contact-us.component.html',
  styleUrl: './contact-us.component.css'
})
export class ContactUsComponent {
  contactForm = {
    name: '',
    email: '',
    telephone: '',
    message: ''
  };

  errors = {
    name: '',
    email: '',
    telephone: '',
    message: ''
  };

  touched = {
    name: false,
    email: false,
    telephone: false,
    message: false
  };

  // Array of forbidden words
  forbiddenWords = ['stupid', 'idiot'];

  onSubmit() {
    // Mark all fields as touched
    this.touched = {
      name: true,
      email: true,
      telephone: true,
      message: true
    };

    // Validate all fields
    this.validateName();
    this.validateEmail();
    this.validateTelephone();
    this.validateMessage();

    // Check if form is valid
    if (this.isFormValid()) {
      console.log('Form submitted:', this.contactForm);
      alert('Thank you for your message! We\'ll get back to you soon.');
      this.resetForm();
    } else {
      alert('Please correct the errors in the form before submitting.');
    }
  }

  onFieldBlur(field: string) {
    this.touched[field as keyof typeof this.touched] = true;
    this.validateField(field);
  }

  onFieldInput(field: string) {
    if (this.touched[field as keyof typeof this.touched]) {
      this.validateField(field);
    }
  }

  validateField(field: string) {
    switch (field) {
      case 'name':
        this.validateName();
        break;
      case 'email':
        this.validateEmail();
        break;
      case 'telephone':
        this.validateTelephone();
        break;
      case 'message':
        this.validateMessage();
        break;
    }
  }

  validateName() {
    const nameValue = this.contactForm.name.trim();
    const hasNumbers = /\d/.test(nameValue);
    
    if (!nameValue) {
      this.errors.name = 'Name is required';
    } else if (nameValue.length < 3) {
      this.errors.name = 'Name must be at least 3 characters long';
    } else if (hasNumbers) {
      this.errors.name = 'Name cannot contain numeric values';
    } else {
      this.errors.name = '';
    }
  }

  validateEmail() {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!this.contactForm.email.trim()) {
      this.errors.email = 'Email is required';
    } else if (!emailRegex.test(this.contactForm.email)) {
      this.errors.email = 'Please enter a valid email address';
    } else {
      this.errors.email = '';
    }
  }

  validateTelephone() {
    const phoneRegex = /^[\+]?[0-9\s\-\(\)]{10,}$/;
    if (this.contactForm.telephone.trim() && !phoneRegex.test(this.contactForm.telephone)) {
      this.errors.telephone = 'Please enter a valid phone number (at least 10 digits)';
    } else {
      this.errors.telephone = '';
    }
  }

  validateMessage() {
    const messageValue = this.contactForm.message.trim();
    
    if (!messageValue) {
      this.errors.message = 'Message is required';
    } else if (messageValue.length < 10) {
      this.errors.message = 'Message must be at least 10 characters long';
    } else {
      // Check for forbidden words
      const foundForbiddenWord = this.checkForForbiddenWords(messageValue);
      if (foundForbiddenWord) {
        this.errors.message = `The word "${foundForbiddenWord}" is not allowed in messages`;
        // Show popup alert
        alert(`"${foundForbiddenWord}" is a forbidden word and cannot be used in your message.`);
      } else {
        this.errors.message = '';
      }
    }
  }

  checkForForbiddenWords(text: string): string | null {
    const lowerCaseText = text.toLowerCase();
    
    for (const word of this.forbiddenWords) {
      // Use word boundary regex to match whole words only
      const wordRegex = new RegExp(`\\b${word.toLowerCase()}\\b`, 'i');
      if (wordRegex.test(lowerCaseText)) {
        return word;
      }
    }
    
    return null;
  }

  isFormValid(): boolean {
    return !this.errors.name && !this.errors.email && !this.errors.telephone && !this.errors.message;
  }

  resetForm() {
    this.contactForm = {
      name: '',
      email: '',
      telephone: '',
      message: ''
    };
    this.errors = {
      name: '',
      email: '',
      telephone: '',
      message: ''
    };
    this.touched = {
      name: false,
      email: false,
      telephone: false,
      message: false
    };
  }
}
