import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './products.component.html',
  styleUrl: './products.component.css'
})
export class ProductsComponent {
  products = [
    {
      id: 1,
      name: 'Mountain Explorer Pro',
      price: 1299.99,
      image: 'https://images.unsplash.com/photo-1571068316344-75bc76f77890?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      description: 'Professional mountain bike built for extreme terrain and adventure seekers.',
      features: ['Carbon Fiber Frame', '21-Speed Shimano Gears', 'Hydraulic Disc Brakes', 'Front & Rear Suspension'],
      inStock: true
    },
    {
      id: 2,
      name: 'City Cruiser Elite',
      price: 699.99,
      image: 'https://images.unsplash.com/photo-1502744688674-c619d1586c9e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      description: 'Elegant city bike perfect for daily commuting and urban adventures.',
      features: ['Lightweight Aluminum Frame', '7-Speed Internal Hub', 'LED Lights Included', 'Comfortable Saddle'],
      inStock: true
    },
    {
      id: 3,
      name: 'Road Runner Speed',
      price: 899.99,
      image: 'https://images.unsplash.com/photo-1485965120184-e220f721d03e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      description: 'High-performance road bike designed for speed and long-distance cycling.',
      features: ['Aerodynamic Design', '16-Speed Racing Gears', 'Carbon Fiber Wheels', 'Drop Handlebars'],
      inStock: false
    }
  ];

  addToCart(product: any) {
    if (product.inStock) {
      console.log('Added to cart:', product.name);
      alert(`${product.name} has been added to your cart!`);
    }
  }
}
