import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  loginForm = {
    email: '',
    password: '',
    rememberMe: false
  };

  showPassword = false;

  onSubmit() {
    console.log('Login attempt:', this.loginForm);
    // Handle login logic here
    alert('Login functionality would be implemented here');
  }

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  onForgotPassword() {
    alert('Forgot password functionality would be implemented here');
  }
}
