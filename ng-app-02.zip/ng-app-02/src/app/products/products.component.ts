import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './products.component.html',
  styleUrl: './products.component.css'
})
export class ProductsComponent {
  products = [
    {
      id: 1,
      name: 'Premium Package',
      price: 99.99,
      description: 'Our top-tier solution with all features included.',
      features: ['Advanced Analytics', '24/7 Support', 'Custom Integration']
    },
    {
      id: 2,
      name: 'Standard Package',
      price: 49.99,
      description: 'Perfect for small to medium businesses.',
      features: ['Core Features', 'Email Support', 'Standard Integration']
    },
    {
      id: 3,
      name: 'Basic Package',
      price: 19.99,
      description: 'Great for getting started with essential features.',
      features: ['Basic Features', 'Community Support', 'Simple Setup']
    }
  ];
}
